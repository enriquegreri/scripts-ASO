#!/bin/bash
#
# Autor: Javier Pedrero Martín - javier@educatica.es
# Fecha 11/02/2019
#
echo "Hola mundo!! El clasico saludo :D"
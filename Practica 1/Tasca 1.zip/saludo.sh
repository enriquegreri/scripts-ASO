#!/bin/bash
#
# Autor: Javier Pedrero Martín
# Fecha: Abril 2018
#
# Muestra un pequeño saludo e información del usuario
echo Bienvenid@s
echo -n Usuario: 
whoami
echo -n Fecha y hora: 
date
echo Procesos:
ps
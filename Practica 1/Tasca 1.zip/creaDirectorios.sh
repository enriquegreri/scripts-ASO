#!/bin/bash
mkdir ~/publico ~/privado ~/compartido ~/publico/documentos ~/publico/musica ~/publico/videos ~/publico/imagenes ~/privado/documentos ~/privado/musica ~/privado/videos ~/privado/imagenes ~/privado/mensajes ~/privado/logs ~/compartido/grupo ~/compartido/empresa ~/compartido/departamento
ls -ld ~/publico ~/privado ~/compartido
ls ~/publico 
ls ~/privado 
ls ~/compartido

